package com.darnell.web.models;

public interface Pet {
	String showAffection();
}
