package com.darnell.web.crud.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.darnell.web.crud.models.Language;
import com.darnell.web.crud.services.LangService;

@Controller
public class Lang {
	
	private final LangService langService;
	public Lang(LangService langService) {
		this.langService = langService;
	}

	@RequestMapping("/")
    public String index()  {
		return "redirect:/languages";
	}
	
	@RequestMapping("/languages")
    public String langs(@ModelAttribute("lang") Language lang, Model model) {
		model.addAttribute("all_langs", langService.allLangs());
		return "index.jsp";
	}
	
	@RequestMapping(path="/lang/new", method=RequestMethod.POST)
	public String newBook(@Valid @ModelAttribute("lang") Language lang, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("all_langs", langService.allLangs());
			return "index.jsp";
        }
		else {
            // Add the Language
			langService.saveLanguage(lang);
			model.addAttribute("all_langs", langService.allLangs());
            return "redirect:/languages";
        }
    }
	
	// Displaying the language
	@RequestMapping(path="/languages/{id}")
	public String display(@PathVariable("id") int id, Model model) {
		Language lang  = langService.findLangByIndex(id);
		model.addAttribute("langs", lang);
		return "display.jsp";
	}
	
	// Updating the language
	@RequestMapping(path="/languages/update/{id}")
	public String update(@PathVariable("id") int id, @Valid @ModelAttribute("lang") Language lang, BindingResult result, Model model) {
		if (result.hasErrors()) {
            return "update.jsp";
        }
		else {
        	langService.updateLang(id, lang);
            return "redirect:/languages";
        }
	}
	
	// Deleting the languages
	@RequestMapping(value="/languages/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		langService.delete(id);
		return "redirect:/languages";
	}
	
	
}
