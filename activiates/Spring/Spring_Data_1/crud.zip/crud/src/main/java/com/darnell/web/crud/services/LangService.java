package com.darnell.web.crud.services;

import java.util.*;
import org.springframework.stereotype.Service;
import com.darnell.web.crud.models.*;

@Service
public class LangService {
	
	
	private ArrayList<Language> create = new ArrayList<Language>(Arrays.asList(
            new Language("Java", "James Gosling", "1.8"),
            new Language("Python", "Guido van Rossum", "3.6"),
            new Language("JavaScript", "Brendan Eich", "85.12")
            ));
    
    // returns all within the list
    public ArrayList<Language> allLangs() {
        return create;
    }
    
    public Language findLangByIndex(int id) {
    	
        if (id < create.size()) {
            return create.get(id);
        }
        else {
            return null;
        }
        
    }
	
    public void saveLanguage(Language l) {
    	create.add(l);
    }

	public void delete(int id) {
		if (id < create.size()){
			create.remove(id);
        }
		
	}
	
	public void updateLang(int id, Language lang) {
        if (id < create.size()){
        	create.set(id, lang);
        }
    }

	
}
